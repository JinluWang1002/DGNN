# The code of DGNN: Decoupled Graph Neural Networks with Structural Consistency between Attribute and Graph Embedding Representations
Runtime Environment:

Python 3.9.12

numpy 1.23.1

torch 1.12.1

pytorch-sparse 2.1.0

All datasets are downloaded from package torch_geometric and saved as series of .pt file without any preprocess procedure. 

email: wangjinlu@emails.bjut.edu.cn   Any questions please contact with me.

